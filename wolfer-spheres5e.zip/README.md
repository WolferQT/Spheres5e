# Spheres5e
FoundryVTT module that adds compendiums with features for Spheres5e.

There are 2 macros to update features' resource consumption since vanilla FoundryVTT doesn't store the targets outside of actors.

Potential incompatibility: I've used the tertiery resource for spell points so spherecasters will be incompatible with any other module that uses it.

Known issue: Spell points max currently needs to be tracked manually.